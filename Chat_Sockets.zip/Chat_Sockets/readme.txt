O projeto foi implementado usando a IDE Netbeans.

Instruções de uso: No terminal vá na pasta onde está salvo a pasta do trabalho e depois coloque o seguinte comando:
cd Chat_Sockets/dist

Exenplo com a pasta salva no Downloads
cd Downloads
cd cd Chat_Sockets/dist

Depois execute o arquivo Servidor.jar com o comando: java -jar "Servidor.jar"

Depois abra um novo terminal e novamente vá a pasta onde está salvo o trabalho e coloque o comando:
cd Chat_Sockets/dist

E depois execute o arquivo Cliente.jar com o comando: java -jar "Cliente.jar"

Depois abra um novo terminal e novamente vá a pasta onde está salvo o trabalho e coloque o comando:
cd Chat_Sockets/dist

E depois execute o arquivo Cliente.jar para simular um segundo cliente com o comando: java -jar "Cliente.jar"

O exemplo abaixo mostra como deve ser colocado as informações ao iniciar um Cliente (no exemplo, considera-se que ja se tenha um Cliente com nome Maria em execução):

O servidor disse: Informe seu nome: 
João

Após informar o nome ele pergunta a quem deseja mandar a mensagem

O servidor disse: Olá João, informe a quem deseja mandar uma mensagem (ex-> ::msgNome)
::msgMaria

Depois pede para digitar a mensagem

O servidor disse: digite uma mensagem para: Maria
Olá Maria

E depois manda uma mensagem que foi enviado com sucesso
O servidor disse: ========== Mensagem enviada ==========


Equipe:Ramon Riuller de Souza e José Carlos Barbosa
