package chat_sockets;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServidorSocket{
    
    public static void main(String[] args) {
        ServerSocket servidor = null;
        //responsavel por incializar o servidor
        try {
            System.out.println("iniciando o servidor......");
            servidor = new ServerSocket(8888); // inicializando o servidor com a porta passada
            System.out.println("Servidor Ativo");
            
            while(true){
                // este accept fica esperando clientes se conectarem
                // e toda vez que se conecta vem um socket
                Socket cliente = servidor.accept();
                // Para cada cliente criado, cria-se um gerenciador pra ele 
                new GerenciadorDeClientes(cliente); 
            }
        } catch (IOException ex) {
            // precisa de tratamento de exceção, caso a porta não esteja fechada
            try {
                if(servidor != null)
                    servidor.close(); 
            } catch (IOException ex1) {}
            System.err.println("Porta ocupada ou o servidor foi fechado"); 
            ex.printStackTrace();
        }
    }
}