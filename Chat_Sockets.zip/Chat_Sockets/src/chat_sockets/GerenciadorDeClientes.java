package chat_sockets;

import com.sun.imageio.plugins.common.InputStreamAdapter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

// Parte responsavel pela comunicação entre o cliente e o servidor, e entre os demais clientes
// a classe Thread é usada para que varios gerenciadores de clientes trabalhe ao mesmo tempo
public class GerenciadorDeClientes extends Thread{ 
    private Socket cliente; //refrencia para todos os clientes quando tiverem que comunicar
    private String nomeCliente; 
    private BufferedReader leitor;
    private PrintWriter escritor;

    //uma variavel que rode com uma instancia só todos os clientes  (map padrão chave-valor)
    private static final Map<String, GerenciadorDeClientes> clientes = new HashMap<String, GerenciadorDeClientes>();
    
    public GerenciadorDeClientes(Socket cliente) {
        this.cliente = cliente;
        
        start(); // iniciando a thread
    }
    
    @Override
    //metodo da classe Thread, responsavel por fazer a conversa
    public void run(){
        try {
            // recebe as mensagens em binário e as transforma em string 
            //precisa de tratamento de exceção,pois alfuma falhana comunicação com o cliente
            leitor = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
            //comunicação(falar) com o cliente 
            escritor = new PrintWriter(cliente.getOutputStream(), true);// para enviar para o cliente
            escritor.println("Informe seu nome: ");
            String msg = leitor.readLine(); // pegando o o input do cliente
            this.nomeCliente = msg;
            escritor.println("Olá " + this.nomeCliente + ", informe a quem deseja mandar uma mensagem (ex-> ::msgNome)");
            
            // joga dentro da map chave e valor, respectivamente (no caso o nome do cliente sera a chave para o valor(si mesmo)
            // assim outros clientes poderão acha-lo
            clientes.put(this.nomeCliente, this);
            while(true){
                msg = leitor.readLine(); // pegando mensagens enquanto  cliente escrever
                
                // o nome que vier depois de "msg", a mensagem será enviada pra ele, ao invés de mandar pro servidor
                if (msg.startsWith("::msg")) { // verifica se a string começa com essa palavra 
                    
                    // 5 (tamanho de "::msg") (ignora os 5 primeiros caracteres e atribui o resto à variavel (pegando asim somente o nome do possível cliente)
                    String nome_destinatario = msg.substring(5, msg.length());
                    
                    System.out.println("Enviando para " + nome_destinatario);
                    GerenciadorDeClientes destinatario = clientes.get(nome_destinatario);
                    if (destinatario == null) { // destinatario não existe no map
                        escritor.println("Cliente informado não existe");
                    }else{ // Destinatário existe, então uma mensagem pode ser criada e enviada
                        escritor.println("Mensagem para: " + destinatario.getNomeCliente());
                        destinatario.getEscritor().println(this.nomeCliente + " disse: " + leitor.readLine());
                        escritor.println("========== Mensagem enviada =========="); // respondendo o cliente
                    }
                }
                
                
            }
            
        } catch (IOException ex) {
            System.out.println("O cliente fechou a conexão");
            ex.printStackTrace(); 
        }
    }

    public PrintWriter getEscritor() {
        return escritor;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }
}