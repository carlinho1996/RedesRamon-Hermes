package chat_sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClienteSocket{
    public static void main(String[] args) {
        try {
        	//inicializa o socket na rede e na porta passada
            Socket cliente = new Socket("127.0.0.1", 8888);
            
            //lendo as mensagens do servidor
            new Thread(){
                @Override
                //metodo da classe Thread, responsavel por fazer a comunicação
                public void run(){
                    try {
                        //   recebe as mensagens em binário e as transforma em string com tratamento de exceção
                        BufferedReader leitor = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
                        
                        while(true){
                            String mensagem = leitor.readLine();
                            System.out.println("O servidor disse: " + mensagem);
                        }
                    //tratamento para o leitor    
                    } catch (IOException ex) {
                        System.out.println("Impossível ler a mensagem");
                        ex.printStackTrace();
                    }
                }
            }.start();
            
            //escrevendo para o servidor
            PrintWriter escritor = new PrintWriter(cliente.getOutputStream(), true);
            BufferedReader leitorTerminal = new BufferedReader(new InputStreamReader(System.in));
            while(true){
                String msgTerminal = leitorTerminal.readLine();
                escritor.println(msgTerminal);
            }
         //tratamento das exceções dos endereço que podem ocorrer
        } catch (UnknownHostException ex) {
            System.out.println("Endereço inválido");
            ex.printStackTrace();
        }catch(IOException e){
            System.out.println("Servidor fora do ar");
            e.printStackTrace();
        }
    }
}